import Cocoa

let speed = 88
let percentage = 85
//let age = 18

if speed >= 88 {
    print("Where wer're going, we don't need roads!")
}

if percentage < 85 {
    print("Sorry, you failed the test.")
    
}

if age >= 18 {
    print("You are able to vote!")
}


let ourName = "Dave Lister"
let friendName = "Arnold Rimmer"

if ourName < friendName {
    print("It's \(ourName) vs \(friendName)")
}

if ourName > friendName {
    print("It's \(friendName) vs \(ourName)")
}

var numbers = [1,2,3]
numbers.append(4)


if numbers.count > 3 {
    numbers.remove(at: 0)
}

print(numbers

)
let country = "Canada"

if country == "Austrralia" {
    print("Gday!")
    }


let name = "Taylor Swift"
 
if name != "Anonymous" {
    print("Welcome, \(name)")
}

var userNmae = "taylorsiwft13"

if userNmae.isEmpty == true {
    userNmae = "Anonymous"
}
print("Welcomem \(userNmae)")


let age = 16

if age >= 18 {
    print("You can vote in the next Election.")
} else {
    print("Sorry, you're too young to vote.")
}

let temp = 25

if temp > 20 && temp < 30 {
    print("It's a nice day!")
}

let userAge = 14
let hasParentalConsent = true
if age >= 18 || hasParentalConsent == true {
    print("You can buy the Game!")
}


enum TransportOption {
    case plane, train, car, helicopter, scooter, rollerblades, bike
}


let transport = TransportOption.plane

if transport == .plane || transport == .helicopter {
    print("Let's fly!")
} else if transport == .bike {
    print("I hope there's a bike path.")
} else if transport == .car {
    print("Time to get sstuck in traffic!")
} else {
    print("Go with God.")
}

enum Weather {
    case sun, rain, wind, snow, unknown
}

let forcase = Weather.sun

switch forcase {
case .sun:
    print("It should be a nice day!")
    
case .rain:
    print("Pack a bumbershoot!")
case .wind:
    print("weat something warm.")
case .snow:
    print("School is Cancelled")
case .unknown:
    print("Our Forecast generator is broken!")
}

let place = "Metropolis"

switch place {
case "Gotham":
    print("You're Batman!")
case "Mega-City One":
    print("You're Judge Dredd!")
case "Wakanda":
    print("You're Black Pather!")
default:
    print("Who are you?")
}

let ageQuestion = 18
let canVote = age >= 18 ? "Yes" : "No"
print(canVote)

let hour = 23
print(hour < 12 ? "It's before noon" : "It's afternoon.")

let names = ["Jamye", "Kaylee", "Mal"]
let crewCount = names.isEmpty ? "No One" : "\(names.count) people"
print(crewCount)


enum Theme {
    case light, dark
}

let theme = Theme.dark

let backGround = theme == .dark ? "black" : "white"
print(backGround)

// thanks JKG
